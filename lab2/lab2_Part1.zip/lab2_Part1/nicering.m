function a = nicering
% A = NICESQUARE wrapper function for SQUARE
a = ring(10000, .3, .5);