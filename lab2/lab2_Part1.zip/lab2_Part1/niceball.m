function a = niceball
% A = NICEBALL wrapper function for BALL
a = ball(10000, .5);
