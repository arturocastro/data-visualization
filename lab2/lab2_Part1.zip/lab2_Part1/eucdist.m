function d = eucdist(x, y)
% D  = EUCDIST(X, Y) returns Euclidean distance between vectors X and Y.

d = mag(x-y);
