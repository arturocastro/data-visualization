function a = nicesquare

a = rand(10000,2);